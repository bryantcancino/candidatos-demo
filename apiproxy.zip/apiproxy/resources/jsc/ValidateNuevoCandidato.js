try{
    var errors = [];
    print(context.getVariable('request.content'));    
    var request = JSON.parse(context.getVariable("request.content"));
    var requestVerb = context.getVariable("request.verb");
    var response = JSON.parse(context.getVariable("response.content"));
    var responseCode = context.getVariable("response.status.code");
    
    if(responseCode === 200 ){
        if(requestVerb !== "PUT"){
            request.idCandidato = create_UUID()
        }
        context.setVariable("request.content",JSON.stringify(request));
        print(context.getVariable('request.content'));
        var postulaciones = request.postulaciones;
        for (var i = 0 in postulaciones) {
            print(postulaciones[i]);
            var existOferta = response.ofertas.filter(elementoOferta => (elementoOferta.idOferta === postulaciones[i]));
            print(existOferta)
            if(existOferta.length<=0){
                errors.push({
                    codigo:"400.1",
                    mensaje:"La oferta seleccionada no existe."
                });
                errors = {
                    "errores": errors
                };
                context.setVariable('payload',JSON.stringify(errors));
                context.setVariable("statusCode", 400);
                context.setVariable("reasonPhrase", "Bad Request");            
                break;
            }
        }        
    } else {
        errors.push({
            codigo:"500.1",
            mensaje:"Ocurrio un error, iontenta más tarde."
        });
        errors = {
            "errores": errors
        };
        context.setVariable('payload',JSON.stringify(errors));
        context.setVariable("statusCode", 500);
        context.setVariable("reasonPhrase", "Internal Server Error");   
    }
    

}catch(e){
    print('/***********************/');
    print("Error: "+e);
    print('/***********************/');
}