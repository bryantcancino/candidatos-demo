try{
    var errors = [];
    
    var cache = context.getVariable("cached.LIST");
    //print(cache);  
    var uriPathCandidato = context.getVariable("uripath.idCandidato");
    //print(uriPathCandidato); 
    //print(context.getVariable('response.content'));  
    var response = JSON.parse(context.getVariable("response.content"));
    var responseCode = context.getVariable("response.status.code");
    
    //print(response);
    
    if(responseCode === 200 ){
        if (cache === null) {
            errors.push({
                codigo:"404.1",
                mensaje:"No se encontraron candidatos."
            });
            errors = {
                "errores": errors
            };
            context.setVariable('payload',JSON.stringify(errors));
            context.setVariable("statusCode", 404);
            context.setVariable("reasonPhrase", "Not Found");    
        } else {
            cache = JSON.parse(cache);
            var candidato = cache.filter(elementoCandidato => (elementoCandidato.idCandidato === uriPathCandidato));

            if(candidato.length > 0){
                var ofertas = [];
                //print(JSON.stringify(candidato));
                var postulaciones = candidato[0].postulaciones;
                for (var j = 0 in postulaciones) {
                    var oferta = response.ofertas.filter(elementoOferta => (elementoOferta.idOferta === postulaciones[j]));
                    //print(JSON.stringify(oferta));
                    if(oferta.length > 0){
                        ofertas.push(oferta[0]);
                    }                
                }
                candidato[0].postulaciones = ofertas;
                context.setVariable('payload',JSON.stringify(candidato[0]));
                context.setVariable("statusCode", 200);
                context.setVariable("reasonPhrase", "OK"); 
            }else{
                errors.push({
                    codigo:"404.1",
                    mensaje:"No se encontraron candidatos."
                });
                errors = {
                    "errores": errors
                };
                context.setVariable('payload',JSON.stringify(errors));
                context.setVariable("statusCode", 404);
                context.setVariable("reasonPhrase", "Not Found");                
            }            
        }        
    } else {
        errors.push({
            codigo:"500.1",
            mensaje:"Ocurrio un error, iontenta más tarde."
        });
        errors = {
            "errores": errors
        };
        context.setVariable('payload',JSON.stringify(errors));
        context.setVariable("statusCode", 500);
        context.setVariable("reasonPhrase", "Internal Server Error");   
    }
        

}catch(e){
    print('/***********************/');
    print("Error: "+e);
    print('/***********************/');
}
