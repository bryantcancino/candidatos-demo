try{
    var data = context.getVariable("response.content");
    data = JSON.parse(data);
    var removeFalsy = function removeFalsy(obj) {
         Object.keys(obj).forEach(function(key) {
             if  (obj[key] && typeof obj[key] === 'object') removeFalsy(obj[key])
            else if (obj[key] === null || obj[key]===undefined || obj[key]==='') delete obj[key]
        });
    
    };
    removeFalsy(data);
    context.setVariable("response.content", JSON.stringify(data));
}catch(e){
    print("***errors: Quit-Null-Params ***");
    print(e);
    print("***end******");
}