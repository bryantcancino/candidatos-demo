try{
    var statusCodeLN = context.getVariable("ResponseLN.status.code");
    var ResponseLN = context.getVariable("ResponseLN.content");
    var payload = JSON.parse(context.getVariable("payload"));

    if(statusCodeLN !== undefined && statusCodeLN === 200 && ResponseLN !== undefined && ResponseLN !== null){
        payload.posibleListaNegra = false;
        context.setVariable('payload',JSON.stringify(payload)); 
    }
    
}catch(e){
    print('/***********************/');
    print("Error validar Lista Negra: "+e);
    print('/***********************/');
}


try{
    var statusCodeCP = context.getVariable("ResponseCP.status.code");
    var responseCP = context.getVariable("ResponseCP.content");
    var payload = JSON.parse(context.getVariable("payload"));

    if(statusCodeCP !== undefined && statusCodeCP === 200 && responseCP !== undefined && responseCP !== null){
        var entidad = responseCP.match(/Entidad":"[^]*2":"/)[0].replace('Entidad":"', '').replace('","2":"', '');
        var ciudad = responseCP.match(/Ciudad":"[^]*3":"/)[0].replace('Ciudad":"', '').replace('","3":"', '');
        var municipio = responseCP.match(/Municipio":"[^]*4":"/)[0].replace('Municipio":"', '').replace('","4":"', '')
        var colonia = responseCP.match(/Colonia":"[^]*5":"/)[0].replace('Colonia":"', '').replace('","5":"', '')
        var CP_ = responseCP.match(/CP":"[^]*"}]/)[0].replace('CP":"', '').replace('"}]', '')
        var ubicacionValidada = {
            entidad : entidad,
            ciudad : ciudad,
            municipio : municipio,
            colonia : colonia,
            CP : CP_
        };
        payload.ubicacionValidada = ubicacionValidada;

        context.setVariable('payload',JSON.stringify(payload)); 
    }
    
}catch(e){
    print('/***********************/');
    print("Error validar CP: "+e);
    print('/***********************/');
}




try{

    var statusCodeRC = context.getVariable("ResponseCedula.status.code");
    //print(statusCodeRC)
    //print(context.getVariable("ResponseCedula.content"))
    var responseRC = JSON.parse(context.getVariable("ResponseCedula.content"));
    //print(context.getVariable("ResponseCedula.content"))
    var payload = JSON.parse(context.getVariable("payload"));
    
    if(statusCodeRC !== undefined && statusCodeRC === 200 && responseRC !== undefined && responseRC !== null && responseRC !== ""){
        if(responseRC.items.length > 0){
            var educacion = [];
            var items = responseRC.items;
            for (var j = 0 in items) {
                educacion.push({
                    anioreg : items[j].anioreg,
                    desins : items[j].desins,
                    idCedula : items[j].idCedula,
                    nombre : items[j].nombre,
                    paterno : items[j].paterno,
                    materno : items[j].materno,
                    sexo : items[j].sexo,
                    tipo : items[j].tipo,
                    titulo : items[j].titulo
                });
            }
            payload.educacionValidada = educacion;
            context.setVariable('payload',JSON.stringify(payload)); 
        }
    }
    
    
}catch(e){
    print("Error Cedula Profesional: "+e);
}

