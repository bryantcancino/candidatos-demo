var cache = context.getVariable("cached.LIST");
print(cache);  
print(context.getVariable('request.content'));  
var request = JSON.parse(context.getVariable("request.content"));

var list = [];
if (cache === null) {
    print('cache vacia');
    list.push(request);
} else {
    cache = JSON.parse(cache);
    cache.push(request);
    list = cache;
}

context.setVariable("CACHE_LIST", JSON.stringify(list));

context.setVariable('payload',JSON.stringify(request));
context.setVariable("statusCode", 200);
context.setVariable("reasonPhrase", "OK");    