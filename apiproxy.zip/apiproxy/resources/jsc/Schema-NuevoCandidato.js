var accentedCharacters = "àèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ";
var schema = {
    title: 'Nuevo/Actualizar candidato v1',
    type:"object",
    required: ["nombres","apellidoPaterno","apellidoMaterno","CP","RFC", "postulaciones"],             
    properties:{
        nombres:{ type: 'string',"pattern": "^[A-Za-z " + accentedCharacters + "0-9\s]+$"},
        apellidoPaterno:{ type: 'string',"pattern": "^[A-Za-z " + accentedCharacters + "0-9\s]+$"},
        apellidoMaterno:{ type: 'string',"pattern": "^[A-Za-z " + accentedCharacters + "0-9\s]+$"},
        apellidoAdicional:{type: ['string','null'],"pattern": "^[A-Za-z " + accentedCharacters + "0-9\s]+$"},
        fechaNacimiento:{ type: 'string',"pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$"},
        CP:{ type: 'string',"pattern": "^[0-9]{5}$"},
        RFC:{ type: 'string',"pattern": "^(([A-Z]|[a-z]|\s){1})(([A-Z]|[a-z]){3})([0-9]{6})((([A-Z]|[a-z]|[0-9]){3}))"},
        postulaciones:{
            "type": "array", 
            "items": { "type": "number"}
        }
    }
};