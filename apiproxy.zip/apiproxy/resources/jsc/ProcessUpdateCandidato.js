try{

    var errors = [];
    var cache = context.getVariable("cached.LIST");
    var request = JSON.parse(context.getVariable("request.content"));
    var pathIdCandidato  = context.getVariable("uripath.idCandidato");
    
    var list = [];
    if (cache === null) {
        errors.push({
            codigo:"404.1",
            mensaje:"No existe el candidato: cache vacia."
        });
        errors = {
            "errores": errors
        };
        context.setVariable('payload',JSON.stringify(errors));
        context.setVariable("statusCode", 404);
        context.setVariable("reasonPhrase", "Not fount"); 
    } else {
        cache = JSON.parse(cache);
        print(cache);
        print(JSON.stringify(cache));        
        //var candidato = [];
        
        
        var candidato = cache.filter(elementoCandidato => (elementoCandidato.idCandidato === pathIdCandidato));
        
        /*for (var j = 0 in cache) {
            if(cache[j].idCandidato === pathIdCandidato){
                candidato.push(cache[j]);
                delete cache[j];
                break;
            }                
        }*/
        
        print(candidato);
        print(JSON.stringify(candidato));
        if(candidato.length<=0){
            errors.push({
                codigo:"404.2",
                mensaje:"No se encontro el candidato."
            });
            errors = {
                "errores": errors
            };
            context.setVariable('payload',JSON.stringify(errors));
            context.setVariable("statusCode", 404);
            context.setVariable("reasonPhrase", "Not fount"); 
        }else{
            var cacheLimpia = cache.filter(elementoCandidato => (elementoCandidato.idCandidato !== pathIdCandidato));
            
            request.idCandidato = candidato[0].idCandidato
            cacheLimpia.push(request);
            context.setVariable("CACHE_LIST", JSON.stringify(cacheLimpia));
            context.setVariable('payload',JSON.stringify(request));
            context.setVariable("statusCode", 200);
            context.setVariable("reasonPhrase", "OK");             
        }     
        

         
    }
    

}catch(e){
    print('/***********************/');
    print("Error: "+e);
    print('/***********************/');
}
