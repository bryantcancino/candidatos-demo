try{
    var errors = [];
    
    var cache = context.getVariable("cached.LIST");
    print(cache);  
    print(context.getVariable('response.content'));  
    var response = JSON.parse(context.getVariable("response.content"));
    var responseCode = context.getVariable("response.status.code");
    
    print(response);
    
    if(responseCode === 200 ){
        if (cache === null) {
            errors.push({
                codigo:"404.1",
                mensaje:"No se encontraron candidatos."
            });
            errors = {
                "errores": errors
            };
            context.setVariable('payload',JSON.stringify(errors));
            context.setVariable("statusCode", 404);
            context.setVariable("reasonPhrase", "Not Found");    
        } else {
            cache = JSON.parse(cache);
            for (var i = 0 in cache) {
                var ofertas = [];
                print(cache[i]);
                var postulaciones = cache[i].postulaciones;
                for (var j = 0 in postulaciones) {
                    var oferta = response.ofertas.filter(elementoOferta => (elementoOferta.idOferta === postulaciones[j]));
                    print(oferta)
                    if(oferta.length > 0){
                        ofertas.push(oferta[0]);
                    }                
                }
                cache[i].postulaciones = ofertas;
            }
    
            var success = {
                "candidatos": cache
            };
            context.setVariable('payload',JSON.stringify(success));
            context.setVariable("statusCode", 200);
            context.setVariable("reasonPhrase", "OK");        
        }        
    } else {
        errors.push({
            codigo:"500.1",
            mensaje:"Ocurrio un error, iontenta más tarde."
        });
        errors = {
            "errores": errors
        };
        context.setVariable('payload',JSON.stringify(errors));
        context.setVariable("statusCode", 500);
        context.setVariable("reasonPhrase", "Internal Server Error");   
    }
        

}catch(e){
    print('/***********************/');
    print("Error: "+e);
    print('/***********************/');
}
